# social-group-django
Simple group django project
<hr>
<img src="screen/1.png" width="100%">

<hr>
<img src="screen/2.png" width="100%">

<hr>
<img src="screen/3.png" width="100%">

<hr>
<img src="screen/4.png" width="100%">

<hr>
<img src="screen/5.png" width="100%">

<hr>
<img src="screen/6.png" width="100%">

<hr>
<img src="screen/7.png" width="100%">
